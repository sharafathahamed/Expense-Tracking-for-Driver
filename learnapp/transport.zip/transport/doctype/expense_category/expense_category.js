// Copyright (c) 2026, Sharaf and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Expense Category", {
// 	refresh(frm) {

// 	},
// });
