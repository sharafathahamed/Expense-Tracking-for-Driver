import frappe

def on_sleSubmit(doc, method):
	src_warehouse = frappe.db.get_single_value("Stock Transfer Route Settings", "source_warehouse")

	if doc.warehouse != src_warehouse:
		return

	if doc.actual_qty <= 0:
		return

	if doc.voucher_type == "Stock Entry":
		se = frappe.get_cached_doc("Stock Entry", doc.voucher_no)
		if se.stock_entry_type == "Material Issue":
			return

	processed_key = f"stock_transfer_processed_{doc.voucher_type}_{doc.voucher_no}"
	if frappe.flags.get(processed_key):
		return
	frappe.flags[processed_key] = True

	frappe.enqueue(
		"learnapp.material_request_hooks.run_transfer_chain",
		queue="short",
		voucher_type=doc.voucher_type,
		voucher_no=doc.voucher_no,
		src_warehouse=src_warehouse
	)


def run_transfer_chain(voucher_type, voucher_no, src_warehouse):
	src_company = frappe.db.get_single_value("Stock Transfer Route Settings", "source_company")
	intCompany = frappe.db.get_single_value("Stock Transfer Route Settings", "intermediate_company")
	destCompany = frappe.db.get_single_value("Stock Transfer Route Settings", "destination_company")
	dest_warehouse = frappe.db.get_single_value("Stock Transfer Route Settings", "destination_warehouse")
	intermediate_warehouse = getDefWarehouse(intCompany)

	matched_items = get_all_items_for_voucher(voucher_type, voucher_no, src_warehouse)
	if not matched_items:
		return

	create_stock_entry("Material Issue", src_company, matched_items, s_warehouse=src_warehouse)
	create_stock_entry("Material Receipt", intCompany, matched_items, t_warehouse=intermediate_warehouse)
	create_stock_entry("Material Issue", intCompany, matched_items, s_warehouse=intermediate_warehouse)
	create_stock_entry("Material Receipt", destCompany, matched_items, t_warehouse=dest_warehouse)


def get_all_items_for_voucher(voucher_type, voucher_no, src_warehouse):
	rows = frappe.get_all("Stock Ledger Entry",
		filters={"voucher_type": voucher_type, "voucher_no": voucher_no, "warehouse": src_warehouse, "actual_qty": [">", 0]},
		fields=["item_code", "sum(actual_qty) as qty"],
		group_by="item_code")
	return [{"item_code": r.item_code, "qty": r.qty} for r in rows]


def create_stock_entry(entry_type, company, items, s_warehouse=None, t_warehouse=None):
	se = frappe.new_doc("Stock Entry")
	se.stock_entry_type = entry_type
	se.company = company
	for it in items:
		row = {"item_code": it["item_code"], "qty": it["qty"], "allow_zero_valuation_rate": 1}
		if s_warehouse:
			row["s_warehouse"] = s_warehouse
		if t_warehouse:
			row["t_warehouse"] = t_warehouse
		se.append("items", row)
	se.insert(ignore_permissions=True)
	se.submit()
	return se


def getDefWarehouse(company):
	abbr = frappe.get_cached_value("Company", company, "abbr")
	return frappe.db.get_value("Warehouse", {"company": company, "warehouse_name": "Stores"}, "name") or f"Stores - {abbr}"